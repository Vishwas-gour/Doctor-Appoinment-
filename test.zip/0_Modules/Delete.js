function DeleteData(e){
    console.log(e.taget)
}
export default DeleteData;